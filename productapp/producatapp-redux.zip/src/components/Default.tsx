import React from 'react'

export default function Default() {
  return (
    <div>Default</div>
  )
}
